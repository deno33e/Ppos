package com.example.foto2pdf

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import java.io.InputStream
import kotlin.math.max
import kotlin.math.min

class MainActivity : Activity() {
    private val selectedPhotos = mutableListOf<Uri>()
    private lateinit var previewList: LinearLayout
    private lateinit var countLabel: TextView
    private lateinit var exportButton: Button

    private val photoPicker = registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (!uris.isNullOrEmpty()) {
            uris.forEach { uri ->
                try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
                if (!selectedPhotos.contains(uri)) selectedPhotos.add(uri)
            }
            refreshPreview()
        }
    }

    private val pdfCreator = registerForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { uri ->
        if (uri != null) exportPdf(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildScreen()
    }

    private fun buildScreen() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(24), dp(20), dp(20))
            setBackgroundColor(Color.rgb(248, 250, 252))
        }
        val title = TextView(this).apply {
            text = "Foto2PDF"
            textSize = 28f
            setTextColor(Color.rgb(15, 23, 42))
            setTypeface(null, android.graphics.Typeface.BOLD)
        }
        root.addView(title)
        root.addView(TextView(this).apply {
            text = "Ubah foto menjadi dokumen PDF dengan mudah."
            textSize = 14f
            setTextColor(Color.rgb(100, 116, 139))
            setPadding(0, dp(5), 0, dp(18))
        })

        val addButton = Button(this).apply {
            text = "＋  Upload Foto"
            setOnClickListener { photoPicker.launch(arrayOf("image/*")) }
        }
        root.addView(addButton, matchWrap())

        countLabel = TextView(this).apply {
            text = "Belum ada foto dipilih"
            textSize = 14f
            setTextColor(Color.rgb(51, 65, 85))
            setPadding(0, dp(18), 0, dp(10))
        }
        root.addView(countLabel)

        val scroll = ScrollView(this)
        previewList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(previewList)
        root.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        exportButton = Button(this).apply {
            text = "Ekspor PDF"
            isEnabled = false
            setOnClickListener { pdfCreator.launch("Foto2PDF.pdf") }
        }
        root.addView(exportButton, matchWrap())
        setContentView(root)
    }

    private fun refreshPreview() {
        previewList.removeAllViews()
        countLabel.text = "${selectedPhotos.size} foto dipilih · Urutan mengikuti pilihan"
        exportButton.isEnabled = selectedPhotos.isNotEmpty()
        selectedPhotos.forEachIndexed { index, uri ->
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(10), dp(10), dp(10), dp(10))
                setBackgroundColor(Color.WHITE)
            }
            val label = TextView(this).apply {
                text = "Foto ${index + 1}"
                textSize = 14f
                setTextColor(Color.rgb(30, 41, 59))
                setPadding(0, 0, 0, dp(8))
            }
            card.addView(label)
            val image = ImageView(this).apply {
                scaleType = ImageView.ScaleType.FIT_CENTER
                adjustViewBounds = true
                maxHeight = dp(230)
                setBackgroundColor(Color.rgb(241, 245, 249))
            }
            try { image.setImageURI(uri) } catch (_: Exception) {}
            card.addView(image, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(210)))
            val remove = Button(this).apply {
                text = "Hapus foto ini"
                setOnClickListener { selectedPhotos.remove(uri); refreshPreview() }
            }
            card.addView(remove)
            val params = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            params.bottomMargin = dp(12)
            previewList.addView(card, params)
        }
    }

    private fun exportPdf(destination: Uri) {
        if (selectedPhotos.isEmpty()) return
        val document = PdfDocument()
        try {
            selectedPhotos.forEachIndexed { index, uri ->
                val pageInfo = PdfDocument.PageInfo.Builder(595, 842, index + 1).create()
                val page = document.startPage(pageInfo)
                val canvas = page.canvas
                canvas.drawColor(Color.WHITE)
                val bitmap = loadScaledBitmap(uri, 1400, 1800)
                if (bitmap != null) {
                    val margin = 28f
                    val available = RectF(margin, margin, 595f - margin, 842f - margin)
                    val scale = min(available.width() / bitmap.width, available.height() / bitmap.height)
                    val width = bitmap.width * scale
                    val height = bitmap.height * scale
                    val left = (595f - width) / 2f
                    val top = (842f - height) / 2f
                    val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
                    canvas.drawBitmap(bitmap, null, RectF(left, top, left + width, top + height), paint)
                    bitmap.recycle()
                } else {
                    val paint = Paint().apply { color = Color.DKGRAY; textSize = 18f; textAlign = Paint.Align.CENTER }
                    canvas.drawText("Foto ${index + 1} tidak dapat dibaca", 297.5f, 421f, paint)
                }
                document.finishPage(page)
            }
            contentResolver.openOutputStream(destination)?.use { document.writeTo(it) }
            Toast.makeText(this, "PDF berhasil disimpan", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Gagal membuat PDF: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
        } finally {
            document.close()
        }
    }

    private fun loadScaledBitmap(uri: Uri, reqWidth: Int, reqHeight: Int): Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
        var sample = 1
        while (bounds.outWidth / (sample * 2) >= reqWidth && bounds.outHeight / (sample * 2) >= reqHeight) sample *= 2
        val options = BitmapFactory.Options().apply { inSampleSize = sample }
        return contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, options) }
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
    private fun matchWrap() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
}
