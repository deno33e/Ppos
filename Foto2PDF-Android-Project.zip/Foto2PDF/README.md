# Foto2PDF

Aplikasi Android sederhana untuk memilih beberapa foto, melihat preview, lalu mengekspornya menjadi PDF.

## Fitur
- Pilih beberapa foto dari galeri
- Preview foto dan hapus foto yang tidak diinginkan
- Satu foto per halaman PDF A4 portrait
- Foto dipaskan ke halaman tanpa mengubah rasio aspek
- Simpan PDF melalui pemilih lokasi Android

## Build APK
1. Buka folder proyek ini menggunakan Android Studio.
2. Pastikan Android SDK Platform 35 terpasang.
3. Pilih **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. APK debug akan muncul di `app/build/outputs/apk/debug/app-debug.apk`.

Proyek ini menggunakan Android Gradle Plugin 8.6.1 dan Kotlin 2.0.21.
